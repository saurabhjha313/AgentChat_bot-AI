path_dict = {
    "download_pdf": "/api/download_pdf",
    "perform_query": "/query"
}