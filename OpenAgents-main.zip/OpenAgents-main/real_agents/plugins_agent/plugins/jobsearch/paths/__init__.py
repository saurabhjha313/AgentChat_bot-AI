path_dict = {
    "jobs": "/jobs"
}