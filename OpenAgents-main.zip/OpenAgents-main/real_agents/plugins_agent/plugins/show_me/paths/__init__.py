path_dict = {
    "diagram_guidelines": "/diagram-guidelines",
    "render_diagram": "/render",
    "show_carousel": "/show-carousel"
}