path_dict = {"create_qr": "/create-qr-code"}
