path_dict = {
    "cloud_plugin": "/api/v1/cloud-plugin",
    "llm_api": "/api/v1/llm-api"
}
