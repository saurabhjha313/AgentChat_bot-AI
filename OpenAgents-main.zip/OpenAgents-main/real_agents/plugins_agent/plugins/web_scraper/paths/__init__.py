path_dict = {
    "scraper": "/scrape"
}