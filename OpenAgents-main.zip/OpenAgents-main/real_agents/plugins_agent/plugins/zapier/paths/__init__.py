path_dict = {
    "search_actions": "/api/v1/search/actions/",
    "preview_a_zap": "/api/v1/preview-a-zap/",
    "configuration_link": "/api/v1/configuration-link/",
    "exposed": "/api/v1/exposed/",
    "execution_log": "/api/v1/execution-log/{execution_log_id}/",
}
