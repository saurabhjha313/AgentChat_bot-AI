path_dict = {
    "get_radar": "/radar/{location}",
    "weather_forecast": "/weather/forecast/{location}",
    "weather_summary": "/weather/summary/{location}"
}