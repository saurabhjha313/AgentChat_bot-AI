path_dict = {
    "basketball_stats": "/basketball_stats"
}