path_dict = {
    "get_classes": "/classes",
    "search_teachers": "/teachers"
}