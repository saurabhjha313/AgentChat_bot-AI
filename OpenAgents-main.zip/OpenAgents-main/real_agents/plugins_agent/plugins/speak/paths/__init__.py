path_dict = {
    "translate": "/v1/public/openai/translate",
    "explain_task": "/v1/public/openai/explain-task",
    "explain_phrase": "/v1/public/openai/explain-phrase",
}
