path_dict = {"generate_map": "/"}
