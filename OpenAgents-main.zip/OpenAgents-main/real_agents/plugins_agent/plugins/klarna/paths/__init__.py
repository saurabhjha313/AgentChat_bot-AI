path_dict = {
    "products": "/public/openai/v0/products",
}
