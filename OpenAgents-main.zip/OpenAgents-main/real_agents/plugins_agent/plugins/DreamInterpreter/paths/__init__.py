path_dict = {
    "dream_interpreter": "/getDream/{DreamText}",
    "data": "/api/data",
}
