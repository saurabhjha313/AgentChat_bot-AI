path_dict = {
    "search_news": "/ai/news",
}
