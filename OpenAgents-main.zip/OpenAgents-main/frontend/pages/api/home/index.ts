export { default, getServerSideProps } from './home';
