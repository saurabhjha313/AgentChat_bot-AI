export interface ColumnProfileScheme {
  title: string;
  content: string;
}
